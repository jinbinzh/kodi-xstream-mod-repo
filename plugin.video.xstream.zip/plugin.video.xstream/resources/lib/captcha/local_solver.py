# -*- coding: utf-8 -*-
# Python 3
#
# Lokale Captcha-Loeser: alles, was der Client SELBST rechnet — ohne Dienst,
# ohne Schluessel und ohne Kosten. Gegenstueck zu captcha_solver.py (2captcha).
#
# Erster Fall ist Altcha (Proof-of-Work): die Seite liefert eine Challenge,
# der Client sucht die Zahl, deren SHA-256 zusammen mit dem Salt die Challenge
# trifft, und schickt das Ergebnis als Formularfeld zurueck. Kostet nur
# Rechenzeit — deshalb haengt dieser Weg am Schalter `captcha.enabled`, NICHT
# am 2Captcha-Schluessel: wer keinen Dienst bezahlt, soll eine Pruefung, die
# ihn nichts kostet, trotzdem bestehen koennen.
#
# Die Funktionen kennen weder Seite noch Domain. Woher die Challenge-Adresse
# kommt, entscheidet der Aufrufer (bei serienstream steht sie im Markup der
# Episodenseite als data-altcha-challenge-url).

import base64
import hashlib
import json
import time

from resources.lib.config import cConfig
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.logger import logger

# Vorgabe fuer maxnumber, wenn die Seite keinen Wert nennt — die Vorgabe des
# Altcha-Widgets selbst. Nennt die Seite einen Wert (serienstream 09/2026:
# 100000), gilt der; einen Deckel gibt es bewusst nicht: die einzige Bremse ist
# die Zeitgrenze, und die passt sich dem Geraet an — ein schneller Rechner
# schafft in derselben Zeit mehr als ein Fire Stick, ein fester Deckel haette
# ihn nur ausgebremst (Jack 10.09.2026: „Deckel raus, nur Zeitgrenze reicht").
ALTCHA_DEFAULT_MAX_NUMBER = 1000000
# Zeitgrenze fuer die Suche: laenger als das soll kein Klick warten. Zur
# Einordnung: 100.000 SHA-256 dauern hier rund 0,1 s, auf einem schwachen
# Android-Geraet grob eine Sekunde.
ALTCHA_TIME_LIMIT = 30


def local_ready():
    """True, wenn lokal geloest werden darf — nur der Schalter zaehlt.

    Bewusst nicht captcha_ready() aus dem Helper: der prueft auch den
    Schluessel, und ohne Schluessel waere eine kostenlose Pruefung sonst
    still abgeschaltet. Fehlt das Setting (Bestandsnutzer direkt nach dem
    Update), gilt der Vorgabewert an — wie beim Dienst.
    """
    if cConfig().getSetting('captcha.enabled', 'true') != 'true':
        logger.info('Captcha: Dienst ist in den Einstellungen abgeschaltet, kein lokales Loesen')
        return False
    return True


def solve_altcha(sChallengeUrl, sReferer=''):
    """Altcha-Challenge holen, rechnen, Antwort als base64-JSON liefern.

    Ablauf wie im Altcha-Widget: GET auf die Challenge-Adresse liefert JSON mit
    algorithm, challenge, salt, signature und maxnumber. Gesucht wird die Zahl n,
    fuer die SHA-256(salt + n) gleich challenge ist. Die Antwort ist das
    base64-kodierte JSON mit algorithm, challenge, number, salt, signature und
    took — genau die Form, die das Widget in sein verstecktes Feld schreibt.
    Die Signatur wird unveraendert zurueckgegeben, sie prueft der Server.

    Args:
        sChallengeUrl (str): Adresse, die die Challenge liefert
        sReferer (str): Seite, auf der das Widget steht (Referer-Header)

    Returns:
        str: die Antwort fuers Formularfeld oder '' — der Aufrufer entscheidet,
             ob er ohne das Feld weitermacht
    """
    if not local_ready():
        return ''

    # caching=False: jede Challenge gilt genau einmal (Salt mit Ablauf).
    # ignoreErrors=True: ein Fehler hier bekommt kein eigenes Fenster — der
    # Aufrufer fuehrt den Ablauf ohne das Feld fort und meldet selbst, wenn
    # die Seite die Antwort nicht annimmt.
    oRequest = cRequestHandler(sChallengeUrl, caching=False, ignoreErrors=True)
    oRequest.addHeaderEntry('Accept', 'application/json')
    if sReferer:
        oRequest.addHeaderEntry('Referer', sReferer)
    jChallenge = oRequest.requestJson()
    if not isinstance(jChallenge, dict):
        logger.error('Altcha: keine Challenge von %s' % sChallengeUrl)
        return ''

    sAlgorithm = str(jChallenge.get('algorithm', '')).upper()
    sChallenge = str(jChallenge.get('challenge', '')).lower()
    sSalt = str(jChallenge.get('salt', ''))
    sSignature = str(jChallenge.get('signature', ''))
    # Nur SHA-256: andere Algorithmen waeren ein neuer Fall und werden nicht
    # geraten (das Widget kann auch SHA-1/SHA-512, die Seite nutzt SHA-256).
    if sAlgorithm != 'SHA-256' or not (sChallenge and sSalt and sSignature):
        logger.error('Altcha: unbekannte Challenge-Form (%s)' % sAlgorithm)
        return ''
    try:
        iMaxNumber = int(jChallenge.get('maxnumber') or ALTCHA_DEFAULT_MAX_NUMBER)
    except (TypeError, ValueError):
        iMaxNumber = ALTCHA_DEFAULT_MAX_NUMBER

    tStart = time.time()
    sSaltBytes = sSalt.encode('utf-8')
    for iNumber in range(iMaxNumber + 1):
        if hashlib.sha256(sSaltBytes + str(iNumber).encode('utf-8')).hexdigest() == sChallenge:
            iTook = int((time.time() - tStart) * 1000)
            aPayload = {'algorithm': jChallenge.get('algorithm'), 'challenge': jChallenge.get('challenge'),
                        'number': iNumber, 'salt': sSalt, 'signature': sSignature, 'took': iTook}
            logger.info('Altcha geloest: Zahl %d nach %d ms' % (iNumber, iTook))
            # Kompakt wie JSON.stringify im Browser (ohne Leerzeichen)
            return base64.b64encode(json.dumps(aPayload, separators=(',', ':')).encode('utf-8')).decode('ascii')
        if iNumber % 10000 == 0 and time.time() - tStart > ALTCHA_TIME_LIMIT:
            logger.error('Altcha: Zeitgrenze von %d s erreicht bei Zahl %d' % (ALTCHA_TIME_LIMIT, iNumber))
            return ''
    logger.error('Altcha: keine Loesung bis %d' % iMaxNumber)
    return ''
