# -*- coding: utf-8 -*-
# Python 3
"""Wrapper-Resolver fuer die meinecloud-Plattform.

Mehrere DLE-Family-Sites verstecken Hoster hinter dem meinecloud-Aggregator.
Diese Datei buendelt alle meinecloud-spezifische Resolver-Logik (Filme +
Serien) zentral. Gehoert in resources/lib/wrappers/ — beim Hinzufuegen
einer weiteren Wrapper-Plattform: eigenes File im gleichen Ordner anlegen.

Hinweis: Die Plattform heisst technisch meinecloud. Sites labeln sie
unterschiedlich ('Sirius', 'meinecloud', 'Server 1' etc.) — alles dasselbe.
Seit 09/2026 tritt sie zusaetzlich als DEVIDEOSRC auf (devideosrc.co =
Hauptdomain laut eigener Doku, meinecloud.click = Embed-Domain, gleicher
Katalog). Der Wrapper erkennt beide Markennamen (isPlatformUrl) und kann
den neuen JS-Player der Plattform ueber dessen JSON-API aufloesen
(_resolveViaApi); der Serien-Resolver traegt einen Cross-Domain-Fallback.


═══════════════════════════════════════════════════════════════════════
  WRAPPER-NUTZER — welche Sites importieren aus diesem File
═══════════════════════════════════════════════════════════════════════

Eine zentrale Stelle fuer alle Sites die meinecloud-Funktionen importieren
— beim Hinzufuegen/Entfernen einer Site nur HIER aktualisieren.

  sites/hdfilme.py        — Filme Pattern A | Serien MERGE
  sites/kkiste.py         — Filme Pattern C ((URL, Name)-Tupel mit
                            Hostname-Fallback) | Serien MERGE.
                            Movie-Pfad hat eigenen _isValidHoster-Filter
                            und nutzt expandHosterList/buildHosterFromUrl
                            dort NICHT — bewusst um den Filter zu
                            erhalten; der Serien-Pfad laeuft ueber
                            buildMergedHosters (Helper indirekt).
  sites/streamcloud.py    — Filme Pattern D | Serien MC-ONLY
  sites/fhdfilme.py       — Filme Pattern B | Serien FALLBACK
  sites/topstreamfilm.py  — Filme Pattern B | Serien FALLBACK

Pattern-Legende:
  Filme  — Pattern A/B/C/D = unterschiedliche Site-HTML-Strukturen die
           alle in resolveMeinecloud() / expandHosterList() muenden
  Serien — drei Architekturen:
    MERGE     showSeasons + showEpisodes -> showHosters(hosterBlock +
              meinecloud_url). mc wird IMMER geladen und ist das
              Rueckgrat, native Hoster kommen dazu (buildMergedHosters);
              Staffeln/Episoden = Union beider Quellen.
    MC-ONLY   showSeasons + showEpisodes -> showHosters(meinecloud_url).
              Serien-Hoster kommen NUR von mc — natives data-num ist
              fuer mc-Serien tot; Nicht-mc-Serien laufen weiter ueber
              den nativen data-num-Pfad.
    FALLBACK  showSeasons + showEpisodes + showEpisodeHosters. Auf jeder
              Ebene erst natives DLE-Pattern, NUR bei 0 Treffern mc
              (resolveMeinecloudSerial). Liefert nativ irgendwas, wird
              mc gar nicht gefragt — KEIN Merge.

═══════════════════════════════════════════════════════════════════════
  meinecloud (Filme — resolveMeinecloud)
═══════════════════════════════════════════════════════════════════════

Pages: meinecloud Wrapper-URLs (Form: /movie/<imdb>)
Liefert <li ... data-link="//host.com/e/ID"> Hoster-Liste. Die Werte koennen
base64-kodiert sein (Umstellung 09/2026, zuerst auf den movie-Seiten) —
_decodeLink() normalisiert beide Formen an den Parse-Stellen.

Erkennung im Site-HTML:
    <li data-link="https://<meinecloud-host>/movie/<imdb>">LABEL</li>
    Label variiert je nach Site — URL-Pattern bleibt.

Trigger in Site (seit dem devideosrc-Rebranding ueber isPlatformUrl —
beide Markennamen, ein Check):
    from resources.lib.wrappers.meinecloud import resolveMeinecloud, isPlatformUrl
    if isPlatformUrl(sUrl):
        for resolved in resolveMeinecloud(sUrl, referer=URL_MAIN):
            ...

Pattern A — Standard:
    Im Hoster-Loop nach data-link-Match einen Expand-Block einbauen,
    Plattform-URLs durch resolveMeinecloud() expandieren, andere durchreichen.
    Beispiel: sites/hdfilme.py showHosters().

Pattern B — 2-Stage iframe:
    Site filtert das Plattform-iframe per isPlatformUrl und gibt die
    iframe-URL DIREKT in expandHosterList([hUrl]) — Laden und Parsen der
    Wrapper-Seite macht resolveMeinecloud() zentral (inkl. API-Zweig fuer
    den neuen Player). KEIN Selbst-Parse der Wrapper-Seite mehr.
    Beispiel: sites/fhdfilme.py showHosters().

Pattern C — (URL, Name)-Tupel:
    Site nutzt re.findall mit Tupel-Capture. Resolved URLs haben keinen
    Site-Namen — Hostname als Fallback aus URL extrahieren.
    Beispiel: sites/kkiste.py showHosters().

Pattern D — Multi-Mode konvergent:
    Site hat mehrere Modi (Episode/Movie) die in einer gemeinsamen
    Hoster-Loop konvergieren. Expand-Block direkt nach `if isMatch:`,
    faengt alle Modi ab.
    Beispiel: sites/streamcloud.py showHosters().

Filter im Resolver:
    - Leere data-link (Toggle-Buttons "andere Server")
    - Self-Refs auf meinecloud selbst (interne /fullhd/-Links sind Fakes,
      keine echten Streams)

Adversarial-Cases (alle -> []):
    - Leerer Response, Timeout, 403
    - HTML ohne data-link
    - HTML nur mit Self-Refs / leeren Toggles


═══════════════════════════════════════════════════════════════════════
  meinecloud (Serien — resolveMeinecloudSerial)
═══════════════════════════════════════════════════════════════════════

Seit ~05/2026 haben mehrere Sites Serien (z.B. Stranger Things) auf ein
DLE-Template umgestellt das die Staffel/Episoden-Daten NICHT mehr im
Detail-HTML rendert, sondern via JavaScript-Fetch von der meinecloud-Plattform
nachlaedt. Manche alte Serien (z.B. Wednesday) haben die Daten weiterhin in
'su-accordion' + 'se-ac-N' im Detail-HTML.

API-Flow:
    1. Existence-Check:  GET /serials.php?task=check&id_imdb=ttXXXXX
       Response (JSON):  {"exists":true,"player_url":"...","episode_count":N}
                     oder {"exists":false}
    2. Falls exists=true: GET <player_url> liefert die meinecloud-Serial-Page mit
       allen Staffeln/Episoden komplett auf einer Seite.
    3. Episoden-Pattern im meinecloud-HTML:
           data-link="//host/url" data-label="S<N> E<M> — <Titel>"

Aktueller Stand: meinecloud liefert pro Episode nur EINEN Hoster (default
dropload). Der Browser-Player macht keinen zweiten Call fuer mehr Hoster
— Architektur-bedingt ist das was wir kriegen koennen.


═══════════════════════════════════════════════════════════════════════
  meinecloud (Serien-Merge — buildMergedHosters)
═══════════════════════════════════════════════════════════════════════

Fuer die MERGE-Sites: legt native Roh-data-links und die meinecloud-URL
einer Episode zu EINER deduplizierten Hoster-Liste zusammen (native
zuerst, interne Fake-Links raus). Leere Eingaben ok — kein Crash.
Details: Docstring von buildMergedHosters().
"""

import base64
import json
import re
from urllib.parse import urljoin, urlparse

from resources.lib.handler.requestHandler import cRequestHandler, REQUEST_ERRORS
from resources.lib.logger import logger
from resources.lib.tools import cParser, cUtil


# ═══════════════════════════════════════════════════════════════════════
#   meinecloud — gemeinsame Konstanten
# ═══════════════════════════════════════════════════════════════════════

# Trigger-Substring fuer URL-Match. Bewusst nur 'meinecloud' (ohne TLD)
# — robust gegen TLD-Wechsel innerhalb der Plattform-Familie.
MEINECLOUD_TRIGGER = 'meinecloud'

# Zweiter Markenname derselben Plattform (Rebranding 09/2026): DEVIDEOSRC
# ist laut eigener Doku (devideosrc.co) die Hauptdomain, meinecloud.click
# die Embed-Domain — beide teilen Katalog und Hoster. Sites koennen also
# jederzeit auf devideosrc-Embeds umstellen; der Wrapper erkennt beide.
DEVIDEOSRC_TRIGGER = 'devideosrc'
PLATFORM_TRIGGERS = (MEINECLOUD_TRIGGER, DEVIDEOSRC_TRIGGER)

# Bekannte Embed-Hosts der Plattform fuer den Cross-Domain-Fallback im
# Serien-Resolver: liefert ein Host die Episodenliste nicht mehr (der neue
# DEVIDEOSRC-Player rendert sie per JS statt als data-links), wird dieselbe
# Route auf dem Schwester-Host versucht. Bewusste Ausnahme vom
# Kein-Hardcoding-Grundsatz: die Hosts sind Plattform-Eigenschaft (wie die
# Trigger selbst), nicht Seiteninhalt — die Discovery kann nur finden, was
# im Site-HTML steht, und genau das kann beim Umbau der Plattform fehlen.
PLATFORM_SERIAL_HOSTS = ('meinecloud.click', 'devideosrc.co')


def isPlatformUrl(sUrl):
    """True, wenn die URL zur meinecloud/devideosrc-Plattform gehoert.

    Ersetzt den reinen MEINECLOUD_TRIGGER-Substring-Check ueberall dort, wo
    beide Markennamen erkannt werden muessen — in den internen Helpern und
    in den Site-Files, die selbst pruefen (kkiste, fhdfilme). Es gibt keinen
    Substring, der in beiden Markennamen steckt, deshalb eine Funktion statt
    einer zweiten Konstante.
    """
    return bool(sUrl) and any(t in sUrl for t in PLATFORM_TRIGGERS)


# Markup des neuen DEVIDEOSRC-Players (JS-basiert, KEINE data-links im HTML):
#   <main class="player-shell ..." data-type="movie" data-id="tt43708434"
#         data-season="1" data-episode="1" data-mode="default"
#         data-resolve-endpoint="/api/resolve">
# Der Player POSTet type/id/season/episode als JSON an den Endpoint und
# bekommt {"ok":true,"sources":[{"url":...,"name":...,"rank":...},...]}.
# Erkannt wird am MARKUP, nicht an der URL — greift also auch, falls die
# Embed-Domain selbst irgendwann den neuen Player ausliefert.
_RE_API_PLAYER = re.compile(r'<main[^>]+data-resolve-endpoint="([^"]+)"[^>]*>')


def _discoverMeinecloudBase(sHtml):
    """Aus Site-HTML die aktuelle Serien-API-Base der Plattform extrahieren.

    DLE-Sites haben im Inline-JS:
        fetch('https://<host>/serials.php?task=check&id_imdb=' + imdb)
    Wenn TLD oder Markenname wechseln (.click → .io, meinecloud →
    devideosrc), passt der Webmaster die JS-URL an. Der Pfad /serials.php
    bleibt — deshalb matcht das Muster seit dem devideosrc-Rebranding
    HOST-AGNOSTISCH auf den Pfad statt auf den Markennamen (gemessen
    09/2026 ueber alle fuenf Sites und beide Plattform-Domains: null
    Beifang, exakt derselbe Treffer wie das alte meinecloud-Muster).

    Args:
        sHtml: Site-HTML (z.B. die Detail-Page einer Serie)

    Returns:
        'https://<host>' oder None wenn Pattern nicht gefunden.
        Bei None liefert resolveMeinecloudSerial() leere Liste mit Log-
        Eintrag — sauberer Fail statt Crash.
    """
    if not sHtml:
        return None
    m = re.search(r"['\"]https?://([^/'\"]+)/serials\.php", sHtml)
    if m:
        return 'https://' + m.group(1)
    return None


def _resolveViaApi(sPageUrl, sHtml, referer=''):
    """Hoster-URLs ueber die JSON-API des neuen DEVIDEOSRC-Players holen.

    Wird von resolveMeinecloud() gerufen, wenn die geladene Player-Seite
    KEINE data-links traegt, aber das neue Player-Markup (_RE_API_PLAYER).
    Liest type/id/season/episode aus den data-Attributen des <main>-Tags
    und POSTet sie als JSON an den data-resolve-endpoint (relativ zur
    Player-Seite aufgeloest).

    Returns:
        list[str]: Hoster-URLs aus sources[].url (mit Schema, die API
        liefert absolute Adressen). Leer bei Fehler — kein Crash.
    """
    try:
        m = _RE_API_PLAYER.search(sHtml or '')
        if not m:
            return []
        sTag = m.group(0)
        # Attribute einzeln greifen — ihre Reihenfolge im Tag ist nicht
        # garantiert, deshalb kein Sammel-Muster ueber mehrere Attribute.
        def attr(name, default=''):
            mAttr = re.search(r'data-%s="([^"]*)"' % name, sTag)
            return mAttr.group(1) if mAttr else default
        payload = {
            'type': attr('type', 'movie'),
            'id': attr('id'),
            'season': attr('season', '1'),
            'episode': attr('episode', '1'),
            'mode': attr('mode', 'default'),
        }
        if not payload['id']:
            logger.info('wrappers.meinecloud_api: Player-Markup ohne data-id auf %s' % sPageUrl)
            return []
        sEndpoint = urljoin(sPageUrl, m.group(1))
        oRequest = cRequestHandler(sEndpoint, caching=False, ignoreErrors=True, method='POST', data=json.dumps(payload))
        oRequest.addHeaderEntry('Content-Type', 'application/json')
        if referer:
            oRequest.addHeaderEntry('Referer', referer)
        jData = oRequest.requestJson()
        if not jData or jData.get('ok') is False:
            logger.info('wrappers.meinecloud_api: keine brauchbare resolve-Antwort fuer %s (Status %s)' % (payload['id'], oRequest.getStatus()))
            return []
        aUrls = [s.get('url') for s in jData.get('sources') or [] if s.get('url')]
        if aUrls:
            logger.info('wrappers.meinecloud_api: %d Quellen ueber /api/resolve fuer %s' % (len(aUrls), payload['id']))
        return aUrls
    except Exception as e:
        logger.error('wrappers.meinecloud_api: %s bei %s' % (e, sPageUrl))
    return []


def resolveMeinecloud(sUrl, referer=''):
    """Loest meinecloud/devideosrc Wrapper zu Hoster-Liste auf.

    Traegt die Seite data-links (alter Player), werden die geparst wie
    immer. Traegt sie stattdessen das Markup des neuen DEVIDEOSRC-Players,
    kommen die Quellen ueber dessen JSON-API (_resolveViaApi) — erkannt am
    Markup, nicht an der URL, funktioniert also fuer jede URL-Form der
    Plattform (movie/serial/custom, beide Domains, ID mit oder ohne tt).

    Args:
        sUrl: Wrapper-URL der Plattform (aktuelle Form siehe Sektion oben)
        referer: optional Referer-Header (URL der aufrufenden Site)

    Returns:
        list[str]: Hoster-URLs (kann leer sein, kein Crash bei Fehler).
                   URLs koennen protokoll-relativ sein (//host/...) — der
                   Caller muss Schema-Fix machen (https: prefixen).

    WICHTIG fuer Caller — Schema-Fix-Pflicht:
        Resolved URLs kommen oft im protokoll-relativen Format (//host/...).
        ResolveURL kann mit denen NICHT umgehen — Hoster wird still verworfen
        und taucht nicht in der Hoster-Liste auf (Bug-Pattern: 'mixdrop/dropload
        fehlen plötzlich aus der Liste').

        Caller-Code muss IMMER:
            _fixedUrl = ('https:' + url) if url.startswith('//') else url

        Und _fixedUrl muss ans System (link-Feld), NICHT die ungefixte URL.
        Beispiele: sites/kkiste.py showHosters (Movie-Pfad) und sites/streamcloud.py
        showHosters (meinecloud-Mode) — die Helper hier machen den Fix selbst.
    """
    try:
        # caching=False: Hoster-Listen aendern sich haeufig (meinecloud rotiert Server,
        # tote Hoster werden ausgetauscht). Cache wuerde tote Hoster oder leere
        # Responses (Anti-Bot-Treffer) bis zu cacheTime Stunden weiter ausliefern
        # — siehe Bug 04.05.2026: 'mixdrop/dropload tauchen plötzlich nicht mehr auf'.
        # ignoreErrors: ein 4xx auf den Anbieter-Endpunkt heisst „Titel ohne
        # Quelle" (unveroeffentlichte Filme, Sportevents), nicht „Seite kaputt".
        # Ohne das Flag zeigte der requestHandler dafuer das Fehlerfenster mit
        # der meinecloud-Adresse; der Nutzer bekommt stattdessen die normale
        # Meldung ueber die leere Hosterliste. Der Status bleibt im Log.
        oRequest = cRequestHandler(sUrl, caching=False, ignoreErrors=True)
        if referer:
            oRequest.addHeaderEntry('Referer', referer)
        sHtml = oRequest.request()
        if not sHtml or sHtml in REQUEST_ERRORS:
            logger.info('wrappers.meinecloud: keine Antwort von %s (Status %s)' % (sUrl, oRequest.getStatus()))
            return []
        isMatch, aResult = cParser.parse(sHtml, r'data-link="([^"]+)"')
        if not isMatch or not aResult:
            # Neuer DEVIDEOSRC-Player? Der rendert keine data-links mehr,
            # sondern holt die Quellen per JS von /api/resolve — dann tun
            # wir dasselbe. Erkannt am Markup, nicht an der URL.
            aApi = _resolveViaApi(sUrl, sHtml, referer=referer)
            if aApi:
                return [_decodeLink(u) for u in aApi if u]
            logger.info('wrappers.meinecloud: keine data-link Treffer in %s' % sUrl)
            return []
        # Dekodieren VOR dem Plattform-Filter: ein base64-kodierter
        # Plattform-Link kaeme sonst an isPlatformUrl vorbei und liefe als
        # Hoster-Adresse weiter.
        aResult = [_decodeLink(u) for u in aResult]
        return [u for u in aResult if u and not isPlatformUrl(u)]
    except Exception as e:
        logger.error('wrappers.meinecloud: %s bei %s' % (e, sUrl))
    return []


# Hoster-URLs ohne Media-ID. Manche Sites lassen leere Platzhalter im HTML
# stehen (beobachtet auf hdfilme: 'https://voe.sx/e/', '//mixdrop.co/e/',
# '//dr0pstream.com/embed-.html'). Die landen sonst als tote, nicht
# abspielbare Eintraege in der Hoster-Liste. Greift nur wenn nach dem
# Hoster-Praefix wirklich NICHTS mehr kommt — echte IDs bleiben unberuehrt.
# movie|serial sind die meinecloud-eigenen Formen: ein ID-loser Platzhalter
# ('meinecloud.click/movie/') wuerde sonst abgerufen und der 404 dem Nutzer
# als Fehlerfenster gezeigt (beobachtet auf einem verwaisten hdfilme-Beitrag).
EMPTY_ID_PATTERN = re.compile(r'/(?:e|d|f|v|embed|embed-|movie|serial)/?(?:\.html)?$', re.I)


def _decodeLink(sValue):
    """Einen data-link-Wert normalisieren: base64 dekodieren, Klartext durchreichen.

    Die Plattform hat im 09/2026 begonnen, die data-link-Werte base64-kodiert
    auszuliefern ('Ly9kcjBwc3RyZWFtLmNvbS9lL3M4b252eHQ4cmx2aQ==' statt
    '//dr0pstream.com/e/s8onvxt8rlvi'). Kodierte Werte kommen NICHT durch
    buildHosterFromUrl() und die Hosterliste bleibt leer — Symptom an allen
    mc-Sites: 'kein einziger Hoster mehr, obwohl die Seite welche zeigt'.

    Die Umstellung laeuft nur teilweise: am 08.09.2026 lieferten die
    movie-Seiten base64, die serial-Seiten noch Klartext. Deshalb wird nicht
    blind dekodiert, sondern nur, wenn der Wert keine Adresse ist UND die
    Dekodierung eine ergibt. Alles andere bleibt unveraendert — auch bei einem
    Rueckbau der Plattform oder gemischten Listen aendert sich damit nichts.

    Args:
        sValue: roher data-link-Wert aus dem Markup

    Returns:
        str: die Adresse (dekodiert oder unveraendert). Nie None.
    """
    if not sValue:
        return sValue
    sTrimmed = sValue.strip()
    if sTrimmed.startswith('//') or sTrimmed.lower().startswith('http'):
        return sValue
    try:
        # Padding ergaenzen: die Plattform liefert es zwar mit, aber ein
        # fehlendes '=' wuerde sonst eine gueltige Adresse verwerfen.
        sDecoded = base64.b64decode(sTrimmed + '=' * (-len(sTrimmed) % 4)).decode('utf-8', 'ignore').strip()
    except Exception:
        return sValue
    if sDecoded.startswith('//') or sDecoded.lower().startswith('http'):
        return sDecoded
    return sValue


def _fixScheme(sUrl):
    """Protokoll-relative URL (//host/...) auf https: normalisieren.

    Eine Stelle fuer den Schema-Fix, genutzt von buildHosterFromUrl() (dort
    fuer die ausgelieferte URL) und von expandHosterList() (dort nur als
    Dedup-Vergleichsschluessel). Grund: meinecloud liefert //host/x, Sites
    liefern https://host/x — ohne Normalisierung gelten beide als
    verschieden und dieselbe Datei landet zweimal in der Hoster-Liste.
    """
    return ('https:' + sUrl) if sUrl.startswith('//') else sUrl


def expandHosterList(aRawUrls, referer=''):
    """Hoster-Liste expandieren: meinecloud-URLs durch resolveMeinecloud() ersetzen,
    andere durchreichen. Mit Dedup ueber alle Treffer.

    Dedup vergleicht schema-normalisiert (siehe _fixScheme) — //host/x und
    https://host/x zaehlen als derselbe Hoster. Ausgeliefert wird die
    Original-URL unveraendert; den Schema-Fix macht buildHosterFromUrl().

    Args:
        aRawUrls: Liste roher data-link URLs aus Site-HTML
        referer: optional Referer fuer den meinecloud-Request

    Returns:
        list[str]: deduplizierte Liste aller realen Hoster-URLs
                   (kann protokoll-relativ sein — Caller macht Schema-Fix
                   typischerweise via buildHosterFromUrl()).
    """
    seen = set()
    expanded = []
    for sUrl in aRawUrls or []:
        if not sUrl:
            continue
        # ID-lose Platzhalter sofort verwerfen — VOR dem meinecloud-Zweig:
        # ein leerer mc-Link ('meinecloud.click/movie/') liefe sonst als
        # Netzabruf auf einen sicheren 404 und zeigte dem Nutzer ein
        # Fehlerfenster. Fuer die uebrigen Hoster ist es derselbe Filter,
        # der bisher erst in buildHosterFromUrl() griff.
        if EMPTY_ID_PATTERN.search(sUrl):
            continue
        if isPlatformUrl(sUrl):
            for sResolvedUrl in resolveMeinecloud(sUrl, referer=referer):
                if sResolvedUrl and _fixScheme(sResolvedUrl) not in seen:
                    seen.add(_fixScheme(sResolvedUrl))
                    expanded.append(sResolvedUrl)
        elif _fixScheme(sUrl) not in seen:
            seen.add(_fixScheme(sUrl))
            expanded.append(sUrl)
    return expanded


def buildHosterFromUrl(sUrl, sQuality='720', includeQualitySuffix=True):
    """Aus einer Hoster-URL ein Standard-Hoster-Dict bauen.

    Macht alle Standard-Schritte:
        - YouTube-Trailer skippen
        - Schema-Fix (//host/... -> https:)
        - Hostname-Extract als Name
        - Blocked-Hoster-Check (xStream Settings)
        - Quality-Suffix optional

    Args:
        sUrl: Hoster-URL (kann protokoll-relativ sein)
        sQuality: Quality-String fuer Anzeige + Hoster-Dict
        includeQualitySuffix: True -> 'Name [I][720p][/I]', False -> nur 'Name'

    Returns:
        dict mit 'link', 'name', 'displayedName', 'quality' — oder None
        wenn URL geskippt werden soll (YouTube/Blocked/leer/ungueltig).
    """
    if not sUrl:
        return None
    if 'youtube' in sUrl:
        return None
    if EMPTY_ID_PATTERN.search(sUrl):
        return None
    sUrl = _fixScheme(sUrl)
    try:
        sName = cParser.urlparse(sUrl).split('.')[0].strip()
    except Exception:
        sName = ''
    if not sName:
        return None
    try:
        from resources.lib.config import cConfig
        if cConfig().isBlockedHoster(sName)[0]:
            return None
    except Exception:
        pass
    if includeQualitySuffix:
        displayedName = '%s [I][%sp][/I]' % (sName, sQuality)
    else:
        displayedName = sName
    return {
        'link': sUrl,
        'name': sName,
        'displayedName': displayedName,
        'quality': sQuality,
    }


def buildMergedHosters(aNativeRawUrls, sMcUrl='', referer='', sQuality='720'):
    """Kombiniert native Hoster-URLs mit einer meinecloud-Direct-URL zu einer
    deduplizierten Hoster-Dict-Liste ("mc plus deren").

    Hintergrund: Bei Serien die BEIDE Quellen tragen (native DLE-Hoster + meinecloud)
    liefert der native Weg mehrere Hoster pro Episode, meinecloud nur einen. Diese
    Funktion legt beide zusammen — native zuerst (i.d.R. mehr/bessere Hoster), die
    meinecloud-URL als zusaetzlicher Eintrag, Duplikate (gleiche finale URL) raus.

    Args:
        aNativeRawUrls: Liste roher data-link URLs aus dem nativen Site-HTML
                        (koennen meinecloud-Wrapper-URLs sein -> werden expandiert,
                        koennen protokoll-relativ sein). Leer/None -> nur meinecloud.
        sMcUrl:         meinecloud-Direct-URL der Episode (1 Hoster). Leer -> nur native.
        referer:        Referer fuer den meinecloud-Expand-Request.
        sQuality:       Quality-String fuer die Hoster-Dicts.

    Returns:
        list[dict]: deduplizierte Hoster-Dicts (Schema wie buildHosterFromUrl).
                    Kann leer sein (kein Crash).
    """
    hosters = []
    seen = set()
    # Native zuerst — meinecloud-Wrapper expandieren, interne /vod/-Links filtern.
    for sUrl in expandHosterList(aNativeRawUrls or [], referer=referer):
        # Interne Site-URLs (z.B. /vod/vpn.html) raus — aber NICHT protokoll-relative
        # (//host/...) die sind externe Hoster.
        if sUrl.startswith('/') and not sUrl.startswith('//'):
            continue
        hoster = buildHosterFromUrl(sUrl, sQuality=sQuality, includeQualitySuffix=True)
        if hoster and hoster['link'] not in seen:
            seen.add(hoster['link'])
            hosters.append(hoster)
    # meinecloud-URL als zusaetzlicher Hoster
    if sMcUrl:
        hoster = buildHosterFromUrl(sMcUrl, sQuality=sQuality, includeQualitySuffix=True)
        if hoster and hoster['link'] not in seen:
            seen.add(hoster['link'])
            hosters.append(hoster)
    return hosters


def _parseSerialEpisodes(sHtml):
    """Episoden-Eintraege aus einer serial-Player-Seite parsen.

    Herausgezogen aus resolveMeinecloudSerial(), weil der
    Cross-Domain-Fallback denselben Parse auf der Schwester-Host-Seite
    wiederholt. Logik unveraendert (Muster, doppeltes unescape).
    """
    # Pattern: data-link="//host/url" ... data-label="S<N> E<M> — <Titel>"
    # em-dash (—) und en-dash (–) und normaler Bindestrich (-) als Separator zulassen
    pattern = r'data-link="([^"]+)"\s+data-label="(S(\d+)\s+E(\d+)\s*[—–-]\s*([^"]+))"'
    episodes = []
    for sUrl, sLabel, sSeason, sEpisode, sTitle in re.findall(pattern, sHtml or ''):
        if not sUrl:
            continue
        # Die player-Seite liefert die Titel HTML-kodiert, teils doppelt
        # ('&amp;quot;Mistschleuder&amp;quot;' statt '"Mistschleuder"').
        # Zweimal entschaerft deckt beide Stufen ab und laesst saubere
        # Titel unveraendert; zentral hier, damit alle Nutzer des Wrappers
        # (streamcloud, fhdfilme, topstreamfilm, hdfilme) dieselben
        # lesbaren Titel bekommen.
        sTitle = cUtil.unescape(cUtil.unescape(sTitle)).strip()
        sLabel = cUtil.unescape(cUtil.unescape(sLabel)).strip()
        episodes.append({
            'season':  int(sSeason),
            'episode': int(sEpisode),
            'title':   sTitle,
            # Die serial-Seiten liefern (Stand 08.09.2026) noch Klartext,
            # die movie-Seiten schon base64 — _decodeLink deckt beides ab.
            'url':     _decodeLink(sUrl),
            'label':   sLabel,
        })
    return episodes


def resolveMeinecloudSerial(sImdbId, referer='', siteHtml=None):
    """Loest meinecloud Serien-Wrapper zu Episoden-Liste auf.

    Args:
        sImdbId: IMDB-ID der Serie (Format 'tt1234567', mit oder ohne 'tt' prefix)
        referer: optional Referer-Header (URL der aufrufenden Site)
        siteHtml: Site-HTML aus dem die aktuelle meinecloud-Base extrahiert
                  wird (vollstaendig dynamisch, TLD-robust). MUSS gegeben sein —
                  ohne siteHtml returnt der Resolver leere Liste mit Log-Eintrag
                  (sauberer Fail statt Crash).

    Returns:
        Zwei Cross-Domain-Fallbacks (seit dem devideosrc-Rebranding):
        antwortet die entdeckte Base auf den serials.php-Check nicht
        brauchbar, laeuft der Check auf den Schwester-Hosts; liefert die
        player_url-Seite den neuen JS-Player statt data-labels, wird
        dieselbe Route auf dem Schwester-Host geholt. Details an den
        beiden Stellen im Code.

    Returns:
        list[dict]: Episoden mit Hoster-URLs. Jeder Eintrag:
            {
                'season':  int,  # Staffel-Nummer
                'episode': int,  # Episoden-Nummer
                'title':   str,  # Episoden-Titel ohne 'S<N> E<M> —' prefix
                'url':     str,  # Hoster-URL (kann protokoll-relativ sein!)
                'label':   str,  # Original 'S1 E1 — Titel' Label
            }
        Leere Liste bei Fehler/exists=false/Timeout/keine Discovery (kein Crash).

    WICHTIG fuer Caller — Schema-Fix-Pflicht:
        Wie bei resolveMeinecloud — URLs koennen protokoll-relativ sein.
        Caller muss ('https:' + url) if url.startswith('//') else url machen.
    """
    try:
        # IMDB-ID normalisieren (mit oder ohne 'tt' prefix)
        if not sImdbId:
            return []
        if sImdbId.startswith('tt'):
            sImdbId = sImdbId[2:]
        if not sImdbId.isdigit():
            logger.info('wrappers.meinecloud_serial: ungueltige IMDB-ID "%s"' % sImdbId)
            return []

        # Auto-Discovery: aus Site-HTML aktuelle Base extrahieren (TLD-robust).
        # Wenn das HTML kein meinecloud-Pattern enthaelt -> sauberer Fail mit
        # Log-Eintrag, kein Crash. meinecloud-Fallback in der Site greift dann einfach
        # nicht und legacy DLE-Pattern uebernimmt falls vorhanden.
        base = _discoverMeinecloudBase(siteHtml)
        if not base:
            logger.info('wrappers.meinecloud_serial: kein meinecloud-Pattern im Site-HTML — wird uebersprungen')
            return []

        # Step 1: Existence-Check via JSON-API — erst auf der entdeckten
        # Base. Liefert die KEINE brauchbare Antwort (Netzfehler oder kein
        # JSON — so antwortet z.B. devideosrc.co, das /serials.php nicht
        # fuehrt), wird derselbe Check auf den bekannten Schwester-Hosts
        # wiederholt (Cross-Domain-Fallback, PLATFORM_SERIAL_HOSTS). Ein
        # sauberes exists:false stoppt dagegen wie bisher sofort: beide
        # Domains teilen denselben Katalog, ein Zweitversuch braechte nichts.
        aBases = [base] + ['https://' + h for h in PLATFORM_SERIAL_HOSTS if h not in base]
        sPlayerUrl = ''
        for sBase in aBases:
            sCheckUrl = '%s/serials.php?task=check&id_imdb=tt%s' % (sBase, sImdbId)
            # ignoreErrors wie in resolveMeinecloud: ein Fehlerstatus des Anbieters ist
            # hier ein Seitenbestand, kein Fall fuer ein Fehlerfenster.
            oRequest = cRequestHandler(sCheckUrl, caching=False, ignoreErrors=True)
            if referer:
                oRequest.addHeaderEntry('Referer', referer)
            data = oRequest.requestJson()
            if data is None:
                logger.info('wrappers.meinecloud_serial: keine brauchbare check-Antwort von %s fuer tt%s (Status %s)' % (sBase, sImdbId, oRequest.getStatus()))
                continue
            if not data.get('exists'):
                logger.info('wrappers.meinecloud_serial: keine Serien-Daten fuer tt%s' % sImdbId)
                return []
            sPlayerUrl = data.get('player_url', '')
            if not sPlayerUrl:
                logger.info('wrappers.meinecloud_serial: exists=true aber keine player_url fuer tt%s' % sImdbId)
                return []
            if sBase != base:
                logger.info('wrappers.meinecloud_serial: Serien-Check via Schwester-Host %s (entdeckte Base %s antwortet nicht)' % (sBase, base))
            break
        if not sPlayerUrl:
            return []

        # Step 2: meinecloud-Player-Page laden (alle Staffeln/Episoden auf einer Seite)
        oRequest = cRequestHandler(sPlayerUrl, caching=False, ignoreErrors=True)
        if referer:
            oRequest.addHeaderEntry('Referer', referer)
        sHtml = oRequest.request()
        if not sHtml or sHtml in REQUEST_ERRORS:
            logger.info('wrappers.meinecloud_serial: keine player-Antwort fuer tt%s (Status %s)' % (sImdbId, oRequest.getStatus()))
            return []

        # Step 3: Episoden parsen — data-link kommt vor data-label
        # (Muster und Titel-Entschaerfung in _parseSerialEpisodes)
        episodes = _parseSerialEpisodes(sHtml)
        if not episodes and _RE_API_PLAYER.search(sHtml):
            # Die player_url zeigt auf den neuen DEVIDEOSRC-Player — der
            # haelt keine data-labels im HTML, und seine API kennt keine
            # Episodenliste (tv ohne Staffel faellt auf S1E1 zurueck,
            # gemessen 09/2026). Die komplette Liste rendert weiterhin der
            # alte Player: dieselbe Route auf dem Schwester-Host versuchen.
            sPlayerHost = urlparse(sPlayerUrl).hostname or ''
            for sHost in PLATFORM_SERIAL_HOSTS:
                if not sPlayerHost or sHost == sPlayerHost:
                    continue
                sAltUrl = sPlayerUrl.replace(sPlayerHost, sHost, 1)
                oRequest = cRequestHandler(sAltUrl, caching=False, ignoreErrors=True)
                if referer:
                    oRequest.addHeaderEntry('Referer', referer)
                sAltHtml = oRequest.request()
                if not sAltHtml or sAltHtml in REQUEST_ERRORS:
                    continue
                episodes = _parseSerialEpisodes(sAltHtml)
                if episodes:
                    logger.info('wrappers.meinecloud_serial: Episodenliste via Schwester-Host %s (neuer Player auf %s ohne Liste)' % (sHost, sPlayerHost))
                    break
            if not episodes:
                logger.info('wrappers.meinecloud_serial: neuer Player ohne Episodenliste fuer tt%s — Plattformumbau? Kein bekannter Host liefert data-labels' % sImdbId)
                return []
        if not episodes:
            logger.info('wrappers.meinecloud_serial: keine Episoden-Treffer in player-page fuer tt%s' % sImdbId)
            return []
        logger.info('wrappers.meinecloud_serial: %d Episoden geladen fuer tt%s' % (len(episodes), sImdbId))
        return episodes
    except Exception as e:
        logger.error('wrappers.meinecloud_serial: %s bei tt%s' % (e, sImdbId))
    return []
