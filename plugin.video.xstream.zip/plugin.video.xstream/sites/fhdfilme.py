# -*- coding: utf-8 -*-
# Python 3
# Always pay attention to the translations in the menu!


import concurrent.futures
import time
import re
import xbmcgui
from resources.lib.handler.parameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler, REQUEST_ERRORS
from resources.lib.logger import logger
from resources.lib.wrappers.meinecloud import resolveMeinecloud, resolveMeinecloudSerial, expandHosterList, buildHosterFromUrl, isPlatformUrl
from resources.lib.tools import cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'fhdfilme'
SITE_NAME = 'FHD Filme'
SITE_ICON = 'fhdfilme.png'

if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'hdfilme.cafe')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)

URL_MAIN = 'https://' + DOMAIN

URL_NEW = URL_MAIN + '/filme1/'
URL_KINO = URL_MAIN + '/kinofilme/'
URL_SERIES = URL_MAIN + '/serien/'
URL_SEARCH = URL_MAIN + '/?story=%s&do=search&subaction=search'


def load():
    logger.info('Load %s' % SITE_NAME)
    xbmcgui.Window(10000).clearProperty('xstream.fhdfilme.lastSearchText')
    xbmcgui.Window(10000).clearProperty('xstream.fhdfilme.lastYear')
    params = ParameterHandler()
    params.setParam('sUrl', URL_KINO)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30501), SITE_IDENTIFIER, 'showEntries'), params)  # Aktuelle Releases
    params.setParam('sUrl', URL_NEW)
    # /filme1/ ist die komplette Filmliste der Seite (Navigation: „Alle Filme“), keine
    # Neu-Liste — deshalb seit 2026.09.10 „Filme“ (Kategorien-Durchgang mit Jack)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showEntries'), params)  # Filme
    params.setParam('sUrl', URL_SERIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showEntries'), params)  # Series
    params.setParam('Value', 'Genre')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showValue'), params)    # Genre
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)   # Search
    cGui().setEndOfDirectory()


def showValue():
    params = ParameterHandler()
    sValue = params.getValue('Value')
    oRequest = cRequestHandler(URL_MAIN)
    sHtmlContent = oRequest.request()
    pattern = '>{0}</(.*?)</a[^<]*</div>'.format(sValue)
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        isMatch, aResult = cParser.parse(sHtmlContainer, 'href="([^"]+).*?>([^<]+)')
        if isMatch:
            # Bei Genre Navigations-Einträge filtern (sind auch im Hauptmenü)
            nav_slugs = ['filme1', 'kinofilme', 'serien', 'aktuelle-kinofilme-im-kino',
                         'kinofilme-online', 'serienstream-deutsch', 'demnachst',
                         'erotik', 'erotikfilme']
            for sUrl, sName in aResult:
                if sUrl.startswith('/'):
                    sUrl = URL_MAIN + sUrl
                if sValue == 'Genre':
                    slug = sUrl.rstrip('/').split('/')[-1].lower()
                    if slug in nav_slugs:
                        continue
                params.setParam('sUrl', sUrl)
                cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    if not isMatch:
        cGui().showInfo()
        return
    cGui().setEndOfDirectory()


def _hasMeinecloudSerial(sDetailHtml):
    """Fragt den serials-Endpunkt, ob es zu diesem Titel wirklich eine Serie gibt.

    Das blosse Vorhandensein des Snippets auf der Detailseite beweist NICHTS:
    die Seite bettet es auch bei Filmen ein und laesst erst zur Laufzeit
    entscheiden, ob umgeschaltet wird ({"exists":false}). Wer nur auf das
    Snippet prueft, schickt Filme in eine leere Staffelebene — belegt an
    "Mach den Unterschied mit Robin Roberts" und "You and I Are Polar Opposites".
    Die Adresse kommt aus dem Snippet der Seite selbst, damit hier keine
    Fremd-Domain im Code steht.
    """
    isMatch, sCheckUrl = cParser.parseSingleResult(
        sDetailHtml, r"fetch\('(https?://meinecloud[^']*serials\.php\?task=check[^']*)'")
    if not isMatch:
        return False
    isMatch, sImdb = cParser.parseSingleResult(sDetailHtml, r"var imdb = '([^']+)'")
    if not isMatch:
        return False
    jCheck = cRequestHandler(sCheckUrl + sImdb).requestJson()
    return bool(jCheck and jCheck.get('exists'))


def _isSeries(entryUrl):
    """Entscheidet Film oder Serie ueber die Detailseite.

    Die Laufzeit taugt dafuer in KEINE Richtung: Kurzfilme und Specials liegen
    unter 70 Minuten (belegt an "The Punisher - One Last Kill", 48 min, und den
    Robot-Chicken-Titeln aus der Suche), und lange Laufzeiten schuetzen nicht
    vor Serien — "Willkommen bei den Reimanns" steht mit langer Laufzeit in den
    Uebersichtslisten und ist eine Serie; als Film behandelt lief der Klick in einen
    Skriptfehler. Deshalb entscheidet immer die Detailseite: natives DLE-Muster
    data-num oder der meinecloud-serials-Endpunkt. Gleiches Verfahren wie bei
    streamcloud. Die Seiten sind durch _prefetchDetails vorgeladen, der Abruf
    hier trifft also den HTML-Cache des Requesthandlers.
    """
    # ignoreErrors: das ist ein Hilfsabruf zur Serienerkennung, der Nutzer hat
    # diesen Titel nicht angeklickt. Antwortet die Seite mit 5xx/4xx, zeigte der
    # requestHandler dafuer ein Fehlerfenster — beim Oeffnen einer Genre-Liste
    # bis zu zehn hintereinander (Audit 01.09.2026, topstreamfilm 502-Phase:
    # vier Fenster fuer „Drama"). Jetzt schweigt der Abruf, der Eintrag gilt
    # als Film; das Fenster bleibt dem Klick des Nutzers vorbehalten.
    try:
        sDetailHtml = cRequestHandler(entryUrl, ignoreErrors=True).request()
    except Exception:
        return False
    if not sDetailHtml:
        return False
    isMatch, _ = cParser.parseSingleResult(sDetailHtml, r'data-num="\d+x\d+"')
    if not isMatch:
        return _hasMeinecloudSerial(sDetailHtml)
    return bool(isMatch)


def _prefetchDetails(aUrls):
    # Die Serien-Erkennung braucht je Eintrag die Detailseite. Einzeln abgerufen
    # summiert sich das auf der Leitung (Latenz x Listenlaenge); deshalb werden
    # alle Seiten VOR der Ausgabeschleife parallel geholt — dasselbe Muster wie
    # das Meta-Nachladen in xstream.py. _isSeries trifft danach den HTML-Cache
    # des Requesthandlers, es entsteht kein zweiter Netzabruf.
    def _fetch(sUrl):
        try:
            sHtml = cRequestHandler(sUrl, ignoreErrors=True).request()   # Hilfsabruf, siehe _isSeries
        except Exception:
            return  # Fehler behandelt die Einzelpruefung selbst
        try:
            # Der Serien-Check haengt an einem zweiten Abruf. Er laeuft hier im
            # selben Thread mit, sonst wuerde _isSeries ihn je Eintrag einzeln
            # nachholen und die Liste um Latenz x Kandidatenzahl verlaengern.
            _hasMeinecloudSerial(sHtml)
        except Exception:
            pass
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as oPool:
        list(oPool.map(_fetch, aUrls))


def _fetchSearchPage(entryUrl, iPage, pattern, bFrisch=False):
    """Eine Folgeseite der Suche holen.

    Rueckgabe ist (Rohtreffer, bErreicht). bErreicht=False heisst, der Abruf
    selbst ist gescheitert — Timeout, Sperre, 404 oder leere Antwort. Das darf
    NICHT als Ende der Ergebnisse gelten: request() liefert im Fehlerfall einen
    Klartext aus REQUEST_ERRORS, darin findet das Muster nichts, und eine leere
    Trefferliste sieht dann exakt wie die letzte Seite aus. Ein einzelner
    Aussetzer wuerde so die halbe Trefferliste abschneiden (nachgestellt:
    Fehler auf Seite 4 -> 24 statt 108 Rohtreffer).
    """
    sSep = '&' if '?' in entryUrl else '?'
    # Fehler ab Seite 2 werden nicht gemeldet: die Seite blaettert weiter, als sie
    # Ergebnisse hat, und ein 404 dort ist kein Fall fuer ein Fenster.
    # bFrisch=True zwingt am HTML-Cache vorbei: Nachhol- und Bestaetigungs-
    # abrufe muessen den SERVER fragen — der Cache liefert sonst exakt die
    # Antwort zurueck, die gerade geheilt oder bestaetigt werden soll
    # (Drosselseiten mit Status 200 werden wie normale Antworten gecacht).
    oRequest = cRequestHandler('%s%ssearch_start=%d' % (entryUrl, sSep, iPage), ignoreErrors=True, caching=not bFrisch)
    sHtmlContent = oRequest.request()
    if not sHtmlContent or sHtmlContent in REQUEST_ERRORS:
        return [], False
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    return (aResult if isMatch else []), True


# Pause vor jedem Nachholversuch: gibt einem Rate-Limit (429) Luft. Kuerzer
# heilt seltener, laenger kostet nur im Fehlerfall — im Normalfall laeuft
# keine einzige Pause.
RETRY_PAUSE = 0.6


def _fetchMoreSearchPages(entryUrl, pattern, iMaxPages=10, iBatch=4):
    """Folgeseiten einer Suche einsammeln — die Seite blaettert ueber `search_start`.

    Ohne das endet jede Suche nach Seite 1, und weil die Seite ihre Treffer nicht
    nach Relevanz sortiert, stehen Titeltreffer regelmaessig erst weiter hinten.
    Gleiche Bauart wie bei hdfilme, streamcloud und topstreamfilm.

    HINWEIS: die Suche dieser Seite antwortet derzeit serverseitig mit einem
    PHP-Fehler statt mit Ergebnissen — der Helfer greift also erst, wenn die
    Seite ihre Suche wieder liefert. Er steht hier, damit die Site dann nicht
    als einzige der Familie nach Seite 1 abbricht.

    Abbruch ist eine Seite ohne Treffer; der Vorwaerts-Link taugt dafuer nicht,
    er fehlt auf spaeteren Seiten obwohl es weitergeht. Geholt wird in Gruppen
    parallel, sonst liegen die Seiten nacheinander auf der Leitung.
    Fehlertoleranz in zwei Stufen (Anlass: unter der Parallellast fielen je
    Lauf zufaellig ganze Seiten aus und die Trefferzahl wuerfelte — still,
    ohne jede Meldung; gemessen 31.08. an streamcloud):
    - Ein GESCHEITERTER Abruf (Timeout, Sperre, 404) wird nach den Gruppen
      einmal sequenziell mit kurzer Pause nachgeholt statt still verworfen.
    - Eine ERREICHTE Seite ohne Treffer gilt erst als Listenende, wenn ein
      zweiter Abruf das bestaetigt — ein 200er mit leerem Body saehe sonst
      exakt wie das Ende aus. Kostet am echten Ende einen Zusatzabruf.
    Die Treffer werden je Seite gesammelt und in Seitenreihenfolge
    zurueckgegeben, damit Nachgeholtes an der richtigen Stelle landet.
    """
    dPages = {}
    aRetry = []
    iEnde = None
    iPage = 2
    while iPage <= iMaxPages:
        aBatch = list(range(iPage, min(iPage + iBatch, iMaxPages + 1)))
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(aBatch)) as oPool:
            aPages = list(oPool.map(lambda p: _fetchSearchPage(entryUrl, p, pattern), aBatch))
        for iNum, (aRows, bErreicht) in zip(aBatch, aPages):
            if not bErreicht:
                aRetry.append(iNum)
            elif aRows:
                dPages[iNum] = aRows
            else:
                # Ende-Kandidat: einmal bestaetigen, bevor abgebrochen wird.
                time.sleep(RETRY_PAUSE)
                aRows2, bErreicht2 = _fetchSearchPage(entryUrl, iNum, pattern, bFrisch=True)
                if bErreicht2 and not aRows2:
                    iEnde = iNum
                    break
                if aRows2:
                    # Hickser: beim zweiten Abruf war die Seite doch gefuellt.
                    logger.info('searchRetry %s: Seite %d nachgeholt, %d Treffer' % (SITE_NAME, iNum, len(aRows2)))
                    dPages[iNum] = aRows2
                else:
                    # Erst leer-erreicht, dann gescheitert: unklar, Seite fehlt.
                    logger.info('searchRetry %s: Seite %d nicht bestaetigt, Treffer dieser Seite fehlen' % (SITE_NAME, iNum))
        if iEnde is not None:
            break
        iPage += iBatch
    # Nachholrunde: gescheiterte Seiten einmal sequenziell holen. Seiten hinter
    # einem bestaetigten Ende liegen jenseits der Ergebnisse und bleiben weg.
    if iEnde is not None:
        aRetry = [p for p in aRetry if p < iEnde]
    for iNum in aRetry:
        time.sleep(RETRY_PAUSE)
        aRows, bErreicht = _fetchSearchPage(entryUrl, iNum, pattern, bFrisch=True)
        if aRows:
            logger.info('searchRetry %s: Seite %d nachgeholt, %d Treffer' % (SITE_NAME, iNum, len(aRows)))
            dPages[iNum] = aRows
        else:
            logger.info('searchRetry %s: Seite %d weiterhin nicht erreichbar, Treffer dieser Seite fehlen' % (SITE_NAME, iNum))
    aAll = []
    for iNum in sorted(dPages):
        aAll.extend(dPages[iNum])
    return aAll

def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = False
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    sHtmlContent = oRequest.request()
    pattern = 'class="item relative mt-3">.*?href="([^"]+).*?title="([^"]+).*?data-src="([^"]+)(.*?)</div></div>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if isMatch and sSearchText:
        # In der globalen Suche laufen alle Sites gleichzeitig, deshalb dort nur
        # fuenf Seiten je Site. Mit zehn dauerte eine breite Suche ueber Mobilfunk
        # 19 s ("koenig", 412 Treffer) — der Einzelaufruf der Site bleibt bei zehn,
        # dort laeuft nur eine Seite zur Zeit.
        aResult += _fetchMoreSearchPages(entryUrl, pattern, iMaxPages=5 if sGui else 10)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    iShown = 0
    # Detailseiten fuer die Serien-Erkennung parallel vorladen. Der Suchfilter
    # wird vorab angewendet, damit keine verworfenen Eintraege geladen werden.
    _prefetchDetails([sUrl for sUrl, sName, sThumbnail, sDummy in aResult
                      if not sSearchText or cParser.searchTitle(sSearchText, sName)])
    for sUrl, sName, sThumbnail, sDummy in aResult:
        if sSearchText and not cParser.searchTitle(sSearchText, sName):
            continue
        isYear, sYear = cParser.parseSingleResult(sDummy, r'mt-1">[^<]*<span>([\d]+)</span>')
        isDuration, sDuration = cParser.parseSingleResult(sDummy, r'<span>([\d]+)\smin</span>')
        isTvshow = _isSeries(sUrl)
        isQuality, sQuality = cParser.parseSingleResult(sDummy, '">([^<]+)</span>')
        sThumbnail = URL_MAIN + sThumbnail
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        if isYear:
            oGuiElement.setYear(sYear)
        if isDuration:
            oGuiElement.addItemValue('duration', sDuration)
        if isQuality:
            oGuiElement.setQuality(sQuality)
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        oGuiElement.setThumbnail(sThumbnail)
        params.setParam('entryUrl', sUrl)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sName', sName)
        if isYear: params.setParam('sYear', sYear)  # Aki: Year an showSeasons weitergeben
        oGui.addFolder(oGuiElement, params, isTvshow, total)
        iShown += 1
    # Kamen Treffer an, wurden aber ALLE vom Titelfilter verworfen, stand hier
    # ein leeres Verzeichnis ohne Hinweis (belegt mit "koenig", Audit 01.09.2026).
    # BEWUSST VOR dem Pagination-Block: dessen Bedingung schliesst die Suche aus,
    # die Meldung wuerde dort nie erreicht. Gleiches Muster wie in hdfilme.
    if not sGui and not iShown:
        oGui.showInfo()

    if not sGui and not sSearchText:
        # Der Vorwaerts-Pfeil der Seite ist der Beleg — er traegt auf der letzten Seite
        # ein <span> statt eines <a>, das Muster greift dort also bewusst nicht.
        # Zwei Fallen der Seite stecken darin: (1) class="page_next" wird ZWEIMAL
        # vergeben, auch fuer den Zurueck-Pfeil, deshalb der Anker auf der Seitenleiste
        # class="pages"; (2) das frueher hier verwendete nav_ext existiert nur bei langen
        # Listen (es ist die "..."-Auslassung) — bei kurzen Kategorien wie Reality-TV
        # fehlte der Weiter-Eintrag dadurch komplett, und auf der letzten Seite lief das
        # offene href-Muster bis zum ersten Filmlink im Dokument weiter.
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, r'class="pages">.*?page_next">\s*<a[^>]+href="([^"]+)"')
        # Seitenlage fuer den Weiter-Eintrag: die hoechste Zahl der Blaetterleiste ist
        # das Listenende — bei langen Listen steht sie hinter der "…"-Auslassung, bei
        # kurzen sind ohnehin alle Zahlen da (gemessen 04.09.2026 gegen die bisektierten
        # Enden, kurz wie lang). Die aktive Seite steht als <span> in derselben Leiste.
        sPageInfo = ''
        isMatchSiteSearch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, 'class="pages">(.*?)<svg')
        if isMatchSiteSearch:
            isMatchCur, sCurrent = cParser.parseSingleResult(sHtmlContainer, r'<span[^>]*>(\d+)</span>')
            aPages = [int(x) for x in re.findall(r'>(\d{1,6})<', sHtmlContainer)]
            if isMatchCur and aPages:
                sPageInfo = cGui.pageInfo(sCurrent, max(aPages))
        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params, sPageInfo)
        oGui.setView('tvshows' if isTvshow else 'movies')
        oGui.setEndOfDirectory()


def showSeasons():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sTmdbID = params.getValue('tmdbID') or ''
    sName = params.getValue('sName') or ''
    sYear = params.getValue('sYear') or ''  # Aki: Year aus Listen-Ebene uebernehmen
    oRequest = cRequestHandler(sUrl)
    sHtmlContent = oRequest.request()
    pattern = 'class="su-accordion collapse show"(.*?)<br>'
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    aResult = []
    if isMatch:
        isMatch, aResult = cParser.parse(sHtmlContainer, r'#se-ac-(\d+)')

    # meinecloud-Fallback: alte DLE-Pattern leer (z.B. Stranger Things hat Daten nur via
    # meinecloud serials.php Endpoint). Bei 0 Treffern IMDB-ID extrahieren und
    # meinecloud-Resolver fragen. Episoden gruppieren nach Staffel-Nummern.
    if not aResult:
        _, aImdb = cParser.parse(sHtmlContent, r'(tt\d{7,9})')
        sImdbId = aImdb[0] if aImdb else ''
        if sImdbId:
            episodes = resolveMeinecloudSerial(sImdbId, referer=sUrl, siteHtml=sHtmlContent)
            if episodes:
                aResult = sorted({str(ep['season']) for ep in episodes}, key=int)

    if aResult:
        total = len(aResult)
        for sSeason in aResult:
            oGuiElement = cGuiElement(cConfig().getLocalizedString(30512) + ' ' + str(sSeason), SITE_IDENTIFIER, 'showEpisodes')
            oGuiElement.setSeason(sSeason)
            oGuiElement.setMediaType('season')
            if sName:
                oGuiElement.setTVShowTitle(sName)
            if sTmdbID:
                oGuiElement.addItemValue('tmdb_id', sTmdbID)
            if sYear:
                oGuiElement.addItemValue('year', sYear)  # Aki: Year auf Staffel setzen
            oGuiElement.setThumbnail(sThumbnail)
            cGui().addFolder(oGuiElement, params, True, total)
    else:
        cGui().showInfo()
        return
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    entryUrl = params.getValue('entryUrl')
    sName = params.getValue('sName') if params.exist('sName') else ''
    sThumbnail = params.getValue('sThumbnail')
    sSeason = params.getValue('season')
    oRequest = cRequestHandler(entryUrl)
    sHtmlContent = oRequest.request()
    pattern = '#se-ac-%s(.*?)</div></div>' % sSeason
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    aResult = []
    aMeinecloudEpisodes = []  # Bei meinecloud-Fallback: Episoden-Dicts mit Titel
    if isMatch:
        isMatch, aResult = cParser.parse(sHtmlContainer, r'Episode\s(\d+)')

    # meinecloud-Fallback: alte DLE-Pattern leer. IMDB-ID extrahieren, meinecloud
    # fragen, Episoden der angefragten Staffel filtern.
    if not aResult:
        _, aImdb = cParser.parse(sHtmlContent, r'(tt\d{7,9})')
        sImdbId = aImdb[0] if aImdb else ''
        if sImdbId:
            allEps = resolveMeinecloudSerial(sImdbId, referer=entryUrl, siteHtml=sHtmlContent)
            try:
                iSeason = int(sSeason)
            except (TypeError, ValueError):
                iSeason = 0
            aMeinecloudEpisodes = [ep for ep in allEps if ep['season'] == iSeason]
            aMeinecloudEpisodes.sort(key=lambda ep: ep['episode'])
            aResult = [str(ep['episode']) for ep in aMeinecloudEpisodes]

    if aResult:
        total = len(aResult)
        for i, sEpisode in enumerate(aResult):
            # meinecloud-Mode: Episode-Titel aus den Dict-Daten verwenden, sonst nur Nummer
            if aMeinecloudEpisodes:
                ep = aMeinecloudEpisodes[i]
                sLabel = '%s %s — %s' % (cConfig().getLocalizedString(30513), str(sEpisode), ep['title'])
            else:
                sLabel = cConfig().getLocalizedString(30513) + ' ' + str(sEpisode)
            oGuiElement = cGuiElement(sLabel, SITE_IDENTIFIER, 'showEpisodeHosters')
            oGuiElement.setThumbnail(sThumbnail)
            oGuiElement.setMediaType('episode')
            # Staffel und Folge als Infolabel: Kodi wertet beides fuer Fortsetzen und
            # Bibliothek aus, externe Werkzeuge finden die Folge nur darueber.
            oGuiElement.setSeason(sSeason)
            oGuiElement.setEpisode(sEpisode)
            if sName: oGuiElement.setTVShowTitle(sName)
            params.setParam('entryUrl', entryUrl)
            params.setParam('season', sSeason)
            params.setParam('episode', sEpisode)
            cGui().addFolder(oGuiElement, params, False, total)
    else:
        cGui().showInfo()
        return
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def showEpisodeHosters():
    hosters = []
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sSeason = params.getValue('season')
    sEpisode = params.getValue('episode')
    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    pattern = '#se-ac-%s(.*?)</div></div>' % sSeason
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        pattern = r'x%s\sEpisode(.*?)<br' % sEpisode
        isMatch, sHtmlLink = cParser.parseSingleResult(sHtmlContainer, pattern)
        if isMatch:
            isMatch, aResult = cParser.parse(sHtmlLink, 'href="([^"]+)')
            if isMatch:
                sQuality = '720'
                for sUrl in aResult:
                    hoster = buildHosterFromUrl(sUrl, sQuality=sQuality, includeQualitySuffix=True)
                    if hoster:
                        hosters.append(hoster)

    # meinecloud-Fallback: keine Hoster aus DLE-HTML gefunden. IMDB-ID extrahieren,
    # meinecloud fragen, gewuenschte Episode rausfiltern. Aktuell liefert meinecloud
    # nur 1 Hoster pro Episode (default dropload) — Architektur-bedingt.
    if not hosters:
        _, aImdb = cParser.parse(sHtmlContent, r'(tt\d{7,9})')
        sImdbId = aImdb[0] if aImdb else ''
        if sImdbId:
            try:
                iSeason = int(sSeason)
                iEpisode = int(sEpisode)
            except (TypeError, ValueError):
                iSeason = iEpisode = 0
            allEps = resolveMeinecloudSerial(sImdbId, referer=sUrl, siteHtml=sHtmlContent)
            for ep in allEps:
                if ep['season'] != iSeason or ep['episode'] != iEpisode:
                    continue
                hoster = buildHosterFromUrl(ep['url'], sQuality='720', includeQualitySuffix=True)
                if hoster:
                    hosters.append(hoster)

    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def showHosters():
    hosters = []
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    # Plattform-iframe (meinecloud/devideosrc) aus der Film-Seite holen.
    # Pattern robust gegen Attribut-Reihenfolge (src kann zuerst stehen);
    # interner player.php (protokoll-relativ) und YouTube-Trailer werden
    # via isPlatformUrl uebersprungen.
    isMatch, aIframes = cParser.parse(sHtmlContent, r'<iframe[^>]+src="(https?://[^"]+)"')
    hUrl = next((u for u in aIframes if isPlatformUrl(u)), '') if isMatch else ''
    if hUrl:
        sQuality = '720'
        # Laden und Parsen der Wrapper-Seite macht resolveMeinecloud()
        # zentral (via expandHosterList) — inklusive API-Zweig fuer den
        # neuen DEVIDEOSRC-Player und caching=False, weil die Plattform
        # Hoster rotiert. Der fruehere Selbst-Parse hier griffe beim neuen
        # Player (keine data-links im HTML) ins Leere.
        for sHosterUrl in expandHosterList([hUrl], referer=URL_MAIN + '/'):
            hoster = buildHosterFromUrl(sHosterUrl, sQuality=sQuality, includeQualitySuffix=True)
            if hoster:
                hosters.append(hoster)
    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    win = xbmcgui.Window(10000)
    sSearchText = win.getProperty('xstream.fhdfilme.lastSearchText')
    if not sSearchText:
        sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
        if not sSearchText: return
        win.setProperty('xstream.fhdfilme.lastSearchText', sSearchText)
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    showEntries(URL_SEARCH % cParser.quotePlus(sSearchText), oGui, sSearchText)
